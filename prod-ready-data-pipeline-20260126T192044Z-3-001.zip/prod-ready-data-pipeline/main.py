import json
import logging

from airport_conditions.config.spark import session_provider
from bricklayer.monitor import QueryMonitor
from pyspark.sql import DataFrame, functions as psf

from airport_conditions import config, sinks
from airport_conditions.options import CosmosDBCredentials, DataLakeCredentials, RunParameters
from airport_conditions.session import session_exists, create_session
from airport_conditions.source import (
    filter_cycle,
    read_flight_events_from_eventhubs,
    flight_events_primary_record,
    read_flight_events_from_delta_lake,
    warmup,
    erase_delta_partition,
    cooldown,
)

FODS_AIRPORT_CONDITIONS_PRODUCER_NAME = "FODS Airport Conditions"


def create_session_if_not_exists(spark_config: dict):
    """get the session or create one if not exist"""
    if not session_exists():
        create_session("airport-conditions-pipeline", config=spark_config)


@session_provider
def monitor_airport_conditions(df: DataFrame, airport_runways: str, spark=None):
    """call the scala API to generate airport condition reports"""
    jvm = spark._jvm
    jdf = jvm.com.boeing.fods.airportconditions.Main.generateAirportConditions(
        df._jdf, airport_runways
    )
    return DataFrame(jdf, spark)


def add_generator_info(
    airport_conditions: DataFrame, build_version, cycle_version
) -> DataFrame:
    """Add _producerName and _producerVersion columns"""
    return (
        airport_conditions
        .withColumn("_producerName", psf.lit(FODS_AIRPORT_CONDITIONS_PRODUCER_NAME))
        .withColumn("_producerVersion", psf.lit(build_version))
        .withColumn("_navDataCycle", psf.lit(cycle_version))
    )


def add_airport_column(flight_events: DataFrame) -> DataFrame:
    """Add airport column to the flight events dataframe."""
    return flight_events.withColumn(
        "airport", psf.col("references.airport.icao")
    )


@session_provider
def get_airport_runways(spark=None) -> str:
    """Query map data to create a json string that contains airport runways"""
    cycle = config.cycle_version.int
    polygon_path = config.get_polygons_source_path()

    df_polygons = (
        spark.read.format("delta")
        .load(polygon_path)
        .filter(psf.col("cycle") == cycle)
    )

    df_airports = (
        df_polygons
        .filter(psf.col("entity_type") == "airport_area")
        .filter(psf.col("airport").isNotNull())
        .withColumn("iata", psf.element_at("properties", "iata"))
        .withColumn("icao", psf.element_at("properties", "icao"))
        .select("airport", "iata", "icao")
        .distinct()
    )

    df_distinct_runway_areas = (
        df_polygons
        .filter(psf.col("entity_type") == "runway_area")
        .select("airport", "ident")
        .distinct()
    )

    df_runways = (
        df_distinct_runway_areas
        .select("airport", psf.split(psf.col("ident"), "\\.").alias("runways"))
        .select("airport", psf.explode(psf.col("runways")).alias("ident"))
        .withColumn("eid", psf.lit("tbd"))
        .withColumn(
            "runways",
            psf.create_map(
                psf.lit("ident"),
                psf.col("ident"),
                psf.lit("eid"),
                psf.col("eid"),
            ),
        )
        .groupBy("airport")
        .agg(psf.collect_list(psf.col("runways")).alias("runways"))
    )

    df_joined = (
        df_airports
        .join(df_runways, on="airport")
        .drop("airport")
    )

    list_runways = [row.asDict() for row in df_joined.collect()]
    return json.dumps(list_runways)


def dedupe_flight_events(
    flight_events_stream: DataFrame, primary_records: DataFrame
) -> DataFrame:
    return flight_events_stream.join(
        psf.broadcast(primary_records),
        how="inner",
        on=[
            "_utcDate",
            "_producerName",
            "_producerVersion",
            "_navDataCycle",
            "_isActiveCycle",
        ],
    )


def stream_to_events(flight_events_stream: DataFrame) -> DataFrame:
    flight_events_stream = add_airport_column(flight_events_stream)
    airport_runways = get_airport_runways()
    airport_conditions = monitor_airport_conditions(
        flight_events_stream, airport_runways
    )
    return add_generator_info(
        airport_conditions,
        config.build_version.str,
        config.cycle_version.int,
    )


def run_streaming():
    if config.source_from_delta_lake.str:
        flight_events_stream = read_flight_events_from_delta_lake(
            config.get_flight_events_path(),
            config.start_date.str,
        )
    else:
        flight_events_stream = read_flight_events_from_eventhubs(
            config.eventhubs_connection_string.str,
            config.eventhubs_consumer_group.str,
        )

    filtered = filter_cycle(
        flight_events_stream, config.cycle_version.int
    )
    airport_conditions = stream_to_events(filtered)
    query = sinks.for_each_batch(airport_conditions)
    return query


def run_backfill():
    if config.erase_before_backfill.str:
        erase_delta_partition(
            config.get_delta_lake_sink_path(),
            config.backfill_start_date.str,
            config.backfill_end_date.str,
            config.build_version.str,
            config.cycle_version.int,
        )

    flight_events_stream = read_flight_events_from_delta_lake(
        source=config.get_flight_events_path(),
        start=warmup(config.backfill_start_date.str),
        end=cooldown(config.backfill_end_date.str),
        withEventTimeOrder=True,
        maxBytesPerTrigger=config.max_bytes_per_trigger.str,
    )

    primary_records = flight_events_primary_record(
        config.get_flight_events_path(),
        config.backfill_start_date.str,
        config.backfill_end_date.str,
    )

    deduped = dedupe_flight_events(flight_events_stream, primary_records)
    airport_conditions = stream_to_events(deduped)
    query = sinks.for_each_batch(airport_conditions)
    return query


def configure_logging(primary_log_level, secondary_log_level):
    logging.basicConfig(
        level=primary_log_level,
        format="{asctime} {levelname} {name} - {message}",
        style="{",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    logging.getLogger("azure").setLevel(level=secondary_log_level)
    logging.getLogger("py4j").setLevel(level=secondary_log_level)


def run():
    """Starts the job."""
    configure_logging(
        config.log_level.str,
        config.secondary_log_level.str,
    )

    if config.backfill_mode.bool:
        query = run_backfill()
    else:
        query = run_streaming()

    if config.app_insight_credentials.str:
        tags = {
            "pipelineId": config.pipeline_id.str,
            "cycle": config.cycle_version.int,
            "version": config.build_version.str,
            "job": "airport-conditions-pipeline",
        }

        query_monitor = QueryMonitor()
        query_monitor.configure_app_insights_handler(
            config.app_insight_credentials.str,
            tags=tags,
        )
        query_monitor.monitor(query)

    return query
