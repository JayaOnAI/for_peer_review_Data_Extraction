from pyspark.sql import DataFrame
from pyspark.sql import functions as psf

from airport_conditions import config
from airport_conditions.config.spark import session_provider

PARTITION_COLS = ["_utcDate", "_producerName", "_producerVersion", "_navDataCycle"]


@session_provider
def eventhubs_conf(connection_string, consumer_group, spark=None) -> dict:  # pragma: no cover
    conf = {}
    conf["eventhubs.connectionString"] = (
        spark._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(
            connection_string
        )
    )
    conf["eventhubs.consumerGroup"] = consumer_group
    return conf


def write_to_delta_lakes(
    df,
    sink_path,
    merge_schema=False,
    partition_cols=PARTITION_COLS,
    start_date=None,
    end_date=None,
):
    if start_date:
        df = df.filter(psf.col("_utcDate") >= start_date)
    if end_date:
        df = df.filter(psf.col("_utcDate") <= end_date)

    (
        df.coalesce(1)
        .write
        .partitionBy(*partition_cols)
        .format("delta")
        .mode("append")
        .option("mergeSchema", merge_schema)
        .save(sink_path)
    )


def write_to_cosmos_db(df, cosmos_conf):  # pragma: no cover
    return (
        df.write
        .format("cosmos.oltp")
        .mode("Append")
        .options(**cosmos_conf)
        .save()
    )


def for_each_batch(df: DataFrame):  # pragma: no cover
    """Write events to multiple sinks with foreachBatch"""

    def func_foreach_batch(df_batch, batch_id, start_date, end_date):
        """Function called by the foreachBatch sink."""

        if config.write_cosmos_db.str:
            df_cosmos = handle_timestamp_for_cosmos(df_batch, ["publishedTime"])
            write_to_cosmos_db(df_cosmos, config.get_cosmos_config())

        if config.write_delta_lake.str:
            df_delta = convert_utcDate_string_to_date(df_batch)
            write_to_delta_lakes(
                df_delta,
                config.get_delta_lake_sink_path(),
                merge_schema=config.merge_schema.str,
                start_date=start_date,
                end_date=end_date,
            )

    if config.backfill_mode.str:
        checkpoint_path = config.get_backfill_checkpoint_path()
        start_date = config.backfill_start_date.str
        end_date = config.backfill_end_date.str
    else:
        checkpoint_path = config.get_streaming_checkpoint_path()
        start_date = None
        end_date = None

    query = (
        df.writeStream
        .foreachBatch(
            lambda micro_batch, batch_id: func_foreach_batch(
                micro_batch, batch_id, start_date, end_date
            )
        )
        .outputMode("append")
        .option("checkpointLocation", checkpoint_path)
        .trigger(processingTime="30 seconds")
        .queryName(
            f"airport-conditions-pipeline-{config.cycle_version.int}-{config.pipeline_id.str}"
        )
        .start()
    )

    return query


def handle_timestamp_for_cosmos(df: DataFrame, cols: list) -> DataFrame:
    """Cast the timestamps columns in the df, so that it can be written to cosmos DB"""
    for c in cols:
        df = df.withColumn(
            c,
            psf.from_unixtime(
                psf.col(c).cast("double"), "yyyy-MM-dd'T'HH:mm:ss'Z'"
            ),
        )
    return df


def convert_utcDate_string_to_date(df: DataFrame, date_col="_utcDate"):
    return df.withColumn(date_col, psf.to_date(psf.col(date_col), "yyyy-MM-dd"))
