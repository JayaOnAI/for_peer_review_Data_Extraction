import datetime
from typing import Union, Tuple
import delta
from pyspark.sql import DataFrame, functions as psf, Window, Column
from pyspark.sql.types import StructType, StringType, TimestampType, IntegerType, BooleanType, MapType
from airport_conditions.config.spark import session_provider
from airport_conditions.sinks import eventhubs_conf

FODS_FLIGHT_EVENT_PRODUCER_NAME = "FODS Airport Flight Events"
FODS_AIRPORT_CONDITIONS_PRODUCER_NAME = "FODS Airport Conditions"

FLIGHT_EVENT_SCHEMA = StructType() \
    .add("eventId", StringType()) \
    .add("eventType", StringType()) \
    .add("eventTime", TimestampType()) \
    .add("publishedTime", TimestampType()) \
    .add("references", StructType()
         .add("flight", StructType()
              .add("id", StringType())
              .add("callsign", StringType())
              .add("origin", StructType()
                   .add("icao", StringType())
                   .add("iata", StringType())
              )
              .add("destination", StructType()
                   .add("icao", StringType())
                   .add("iata", StringType())
              )
              .add("aircraft", StructType()
                   .add("modeS", StringType())
                   .add("registration", StringType())
                   .add("model", StringType())
              )
              .add("airport", StructType()
                   .add("icao", StringType())
                   .add("iata", StringType())
              )
         )
    ) \
    .add("sources", StructType()
         .add("navDataCycle", IntegerType())
         .add("flightDataSource", StringType())
         .add("sourceFlightId", StringType())
    ) \
    .add("_producerName", StringType()) \
    .add("_producerVersion", StringType()) \
    .add("_navDataCycle", IntegerType()) \
    .add("_isActiveCycle", BooleanType()) \
    .add("_isPublic", BooleanType()) \
    .add("_debug", MapType(StringType(), StringType())) \
    .add("_utcDate", StringType()) \
    .add("eventBody", StringType())

def parse_eventBody(events: DataFrame) -> DataFrame:
    """parse the message from eventhub according to the schema"""
    return events \
        .withColumn("parsedBody", psf.from_json(psf.col("body"), FLIGHT_EVENT_SCHEMA)) \
        .select("parsedBody.*")

def filter_cycle(df, cycle_version):
    """ """
    return df.filter(psf.col("_navDataCycle") == cycle_version)

@session_provider
def read_flight_events_from_eventhubs(connection_string, consumer_group, spark=None) -> DataFrame:  # pragma: no cover
    config = eventhubs_conf(connection_string, consumer_group)
    events = spark \
        .readStream \
        .format("eventhubs") \
        .options(**config) \
        .load() \
        .select(psf.col("body").cast(StringType())) \
        .filter(psf.col("body").contains(FODS_FLIGHT_EVENT_PRODUCER_NAME))
    parsed = parse_eventBody(events)
    return parsed

def latest_version(semantic_version: Union[str, Column]) -> Tuple[Column, ...]:
    """
    Parse the semantic version into major, minor, patch and optional "rc" and
    return a tuple of columns for sorting.

    Usage example:
    >>> df.orderBy(*latest_version(df.semVer), df.otherCol)
    """
    FODS_VERSION_RE = r"(\d+)\.(\d+)\.(\d+)(?:$|rc(\d+)$)"
    return (
        psf.regexp_extract(semantic_version, FODS_VERSION_RE, 1).cast("integer").alias("major").desc(),
        psf.regexp_extract(semantic_version, FODS_VERSION_RE, 2).cast("integer").alias("minor").desc(),
        psf.regexp_extract(semantic_version, FODS_VERSION_RE, 3).cast("integer").alias("patch").desc(),
        psf.regexp_extract(semantic_version, FODS_VERSION_RE, 4).cast("integer").alias("rc").desc_nulls_first(),
    )

@session_provider
def load_flight_events(path, start_date, end_date, spark=None) -> DataFrame:
    """
    Read the flight events in batch mode and filter by the date range.
    """
    return spark \
        .read \
        .format("delta") \
        .load(path) \
        .filter(psf.col("_producerName") == FODS_FLIGHT EVENT_PRODUCER_NAME) \
        .filter(psf.col("_utcDate") >= start_date) \
        .filter(psf.col("_utcDate") <= end_date)

def flight_events_primary_record(path, start_date, end_date) -> DataFrame:
    """
    Read the flight events table and get the most updated combination of
    _producerVersion and _navDataCycle for each _utcDate by the following criteria:
    1) most recent version,
    2) active cycle,
    3) most recent cycle
    """
    events = load_flight_events(path, start_date, end_date).cache()
    one_day = Window().partitionBy("_utcDate")
    producer_rank = (
        *latest_version("_producerVersion"),
        psf.col("_isActiveCycle").desc(),
        psf.col("_navDataCycle").desc()
    )
    composite_key = (
        events
        .withColumn("dataProducerRank", psf.row_number().over(one_day.orderBy(*producer_rank)))
        .filter(psf.col("dataProducerRank") == 1)
    )
    return composite_key.select(
        "_utcDate",
        "_producerName",
        "_producerVersion",
        "_isActiveCycle",
        "_navDataCycle"
    ).distinct()

@session_provider
def read_flight_events_from_delta_lake(source: str,
                                       start: str,
                                       end=None,
                                       withEventTimeOrder=False,
                                       maxBytesPerTrigger=None,
                                       spark=None) -> DataFrame:
    """Prepare a streaming data frame."""
    reader = spark \
        .readStream \
        .format("delta") \
        .option("withEventTimeOrder", withEventTimeOrder) \
        .option("ignoreDeletes", True)
    if maxBytesPerTrigger:
        reader = reader.option("maxBytesPerTrigger", maxBytesPerTrigger)
    reader = reader \
        .load(source) \
        .filter(psf.col("_utcDate") >= start) \
        .filter(psf.col("_producerName") == FODS_FLIGHT EVENT_PRODUCER_NAME)
    if end:
        reader = reader.filter(psf.col("_utcDate") <= end)
    return reader

def warmup(start_date, warmup_period=1):
    return (
        datetime.datetime.fromisoformat(start_date).date()
        - datetime.timedelta(days=warmup_period)
    ).isoformat()

def cooldown(end_date, cooldown_period=1):
    return warmup(end_date, warmup_period=-1 * cooldown_period)

@session_provider
def erase_delta_partition(data_path,
                          start_date: str,
                          end_date: str,
                          producer_version: str,
                          cycle: str,
                          producer_name=FODS AIRPORT CONDITIONS_PRODUCER_NAME,
                          spark=None) -> None:
    delta_table = delta.DeltaTable.forPath(spark, data_path)
    delta_table.delete(
        (psf.col("_utcDate").between(start_date, end_date)) &
        (psf.col("_producerName") == producer_name) &
        (psf.col("_producerVersion") == producer_version) &
        (psf.col("_navDataCycle") == cycle)
    )
